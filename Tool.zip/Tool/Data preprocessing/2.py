import pandas as pd

# 假设文件名为"data.txt"，并且以制表符或逗号分隔
df = pd.read_csv('DJI668.txt', delimiter=' ')  # 使用适当的分隔符

# 输出列名以检查是否存在 'class' 列
print(df.columns)

# 如果需要剔除 class 列中名称为 motor 和 pedestrian 的行
if 'class' in df.columns:
    df = df[~df['class'].isin(['motor', 'pedestrian'])]
    print(df)
else:
    print("数据框中没有 'class' 列")

# 定义一个函数来处理landid的值
def update_landid(value):
    if pd.isna(value):  # 检查是否为NaN
        return value
    # 将字符串转换为小写并去掉多余空格
    value = value.strip()
    if value == '2 3':
        return '3'
    elif value == '1 2':
        return '2'
    elif value == '3 4':
        return '4'
    return value  # 如果不匹配，则返回原值

# 应用函数更新landid列
df['landid'] = df['landid'].astype(str).apply(update_landid)

# 检查更新后的数据
print("更新后的landid列:")
print(df['landid'])

# 如果需要保存为新的文件，可以使用以下代码
df.to_csv('DJI669.txt', index=False, sep=' ', float_format='%.2f')  # 替换为你的输出文件路径
