import pandas as pd

# 导入txt文件
file_path = 'DJI673.txt'  # 替换为你的文件路径
data = pd.read_csv(file_path, delimiter=' ')

# 统计每个车辆ID的帧数
frame_counts = data['id'].value_counts()

# 获取帧数大于等于8的车辆ID
valid_ids = frame_counts[frame_counts >= 8].index

# 剔除帧数不足8帧的车辆ID
filtered_data = data[data['id'].isin(valid_ids)]

# 删除重复的Frame，只保留每个车辆ID的第一个出现的行
filtered_data = filtered_data.drop_duplicates(subset=['Frame', 'id'], keep='first')

# 统计剩余车辆的数量
num_cars = filtered_data['id'].nunique()

# 输出结果
print(f"总共有 {num_cars} 辆车帧数大于等于8帧。")
filtered_data.to_csv('DJI674.txt', sep=' ', index=False)
