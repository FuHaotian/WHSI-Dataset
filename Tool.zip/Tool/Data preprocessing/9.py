import pandas as pd

# 读取txt文件
df = pd.read_csv('DJI676.txt', delimiter=' ')

# 确保数据按id和时间排序
df.sort_values(by=['id', 'Frame'], inplace=True)

# 遍历数据
for i in range(1, len(df)):
    if df.loc[i, 'id'] == df.loc[i-1, 'id']:
        # 向上查找前一行 X 不为 0 的行
        for j in range(i-1, -1, -1):
            if df.loc[j, 'X'] != 0:
                if df.loc[i, 'X'] > df.loc[j, 'X']:
                    df.loc[i, 'X'] = 0
                break

# 保存修改后的数据到新的文件
df.to_csv('DJI677.txt', sep=' ', index=False)
