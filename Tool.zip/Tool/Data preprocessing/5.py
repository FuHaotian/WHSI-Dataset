import pandas as pd

# 读取原始数据框，确保使用适当的分隔符
df = pd.read_csv('DJI672.txt', delimiter=' ')  # 或者使用 delimiter=' '，视情况而定

# 检查列名和数据类型
print(df.columns)  # 查看列名
print(df.dtypes)   # 查看数据类型

# 提取landid为1、2、3、4的数据
landid_filtered = df[df['landid'].isin([1, 2, 3, 4])]

# 检查提取的行数
print(f"Filtered landid rows: {len(landid_filtered)}")  # 查看过滤后的数据行数

# 记录车辆id
vehicle_ids = landid_filtered['id'].unique()  # 假设车辆ID列名为'id'

# 根据车辆id提取原始数据中对应的行
extracted_rows = df[df['id'].isin(vehicle_ids)]

# 检查提取的行数
print(f"Extracted rows based on vehicle ids: {len(extracted_rows)}")  # 查看提取后的数据行数

# 保存提取的行到文件
extracted_rows.to_csv('DJI673.txt', index=False, sep=' ')

