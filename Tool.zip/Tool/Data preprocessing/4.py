# 导入所需库
import pandas as pd

# 读取 txt 文件，假设文件名为 'vehicles.txt'
# 假设车辆 ID 是以逗号分隔的格式存储在文件中
df = pd.read_csv('DJI671.txt', delim_whitespace=True)

# 根据 'id' 列进行排序，但保持每辆车的帧率排布
df_sorted = df.sort_values(by=['id', 'Frame']).reset_index(drop=True)

# 将 'class' 列中的 'van' 替换为 'car'
df_sorted['class'] = df_sorted['class'].replace('van', 'car')
df_sorted['class'] = df_sorted['class'].replace('truck', 'car')

# 输出排序后的结果
print(df_sorted)

# 如果需要将排序后的结果保存到新的 txt 文件
df_sorted.to_csv('DJI672.txt', index=False, sep=' ')
