import pandas as pd
import numpy as np
from scipy.interpolate import CubicSpline
from tqdm import tqdm  # 导入 tqdm 库

# 假设您已经导入数据并存储在 df 中
df = pd.read_csv('DJI675.txt', delimiter=' ')

# 计算帧率差值
df['Frame_Diff'] = df['Frame'].diff()

# 找到不连续的帧率位置，考虑相同车辆的 ID
discontinuous_indices = df[(df['Frame_Diff'] > 1) & (df['Frame_Diff'] < 50) & (df['id'].diff() == 0)].index

# 初始化进度条
for idx in tqdm(discontinuous_indices, desc="Processing Discontinuous Frames", unit="frame"):
    start_index = idx - 1  # 不连续帧的前一行
    end_index = idx  # 不连续帧的当前行
    start_value = df.at[start_index, 'X']  # 记录起始行的 X 值
    start_id = df.at[start_index, 'id']  # 记录起始行的 id 值

    # 确保从不连续的帧开始，查找是否同车辆的帧X值递增
    while end_index < len(df):
        current_value = df.at[end_index, 'X']
        current_id = df.at[end_index, 'id']  # 当前行的 id 值

        # 只处理相同车辆的 id
        if current_id != start_id:
            break  # 如果不相同，跳出当前循环

        # 如果当前 X 值小于起始行的 X 值，则跳出插值处理
        if current_value < start_value:
            break

        # 如果当前 X 值大于或等于起始行的 X 值，继续向下查找
        end_index += 1

    # 如果发现连续帧中 X 值是递增的，需要进行插值
    if end_index < len(df) and df.at[end_index, 'X'] < start_value:
        frames_to_interpolate = df.loc[start_index + 1:end_index - 1, 'Frame'].values
        values_to_interpolate = df.loc[start_index + 1:end_index - 1, 'X'].values

        # 确保帧值是递增的
        if df.at[start_index, 'Frame'] < df.at[end_index, 'Frame']:
            # 使用样条插值进行填充
            cs = CubicSpline([df.at[start_index, 'Frame'], df.at[end_index, 'Frame']], [start_value, df.at[end_index, 'X']])
            df.loc[start_index + 1:end_index - 1, 'X'] = np.round(cs(frames_to_interpolate), 1)

        else:
            # 如果帧值没有递增，跳过插值
            df.loc[start_index + 1:end_index - 1, 'X'] = start_value

# 删除辅助列
df.drop(columns=['Frame_Diff'], inplace=True)

# 输出结果到 TXT 文件
df.to_csv('DJI676.txt', sep=' ', index=False)