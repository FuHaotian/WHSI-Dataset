# # 读取原始文件
# with open('DJI_0666_out.txt', 'r') as file:
#     data = file.read()
#
# # 替换逗号为空格
# data = data.replace(',', ' ')  # 或者使用 data.replace(',', '    ') 替换为多个空格
#
# # 保存到新的文件
# with open('DJI667.txt', 'w') as file:
#     file.write(data)


import pandas as pd

# 导入TXT文件
# 假设文件名为"data.txt"，并且以制表符或逗号分隔
df = pd.read_csv('DJI667.txt', delimiter=' ')  # 使用适当的分隔符

# 在最后一列后添加名为'sign'的新列
df['sign'] = ''  # 可以根据需要初始化列的值

# 根据条件填充'sign'列
df.loc[df['Frame'] < 720, 'sign'] = 'r'
df.loc[(df['Frame'] >= 721) & (df['Frame'] <= 1830), 'sign'] = 'g'
df.loc[(df['Frame'] >= 1831) & (df['Frame'] <= 1920), 'sign'] = 'y'
df.loc[(df['Frame'] >= 1921) & (df['Frame'] <= 4470), 'sign'] = 'r'
df.loc[(df['Frame'] >= 4471) & (df['Frame'] <= 5580), 'sign'] = 'g'
df.loc[(df['Frame'] >= 5581) & (df['Frame'] <= 5670), 'sign'] = 'y'
df.loc[(df['Frame'] >= 5671) & (df['Frame'] <= 8190), 'sign'] = 'r'
df.loc[(df['Frame'] >= 8191) & (df['Frame'] <= 9300), 'sign'] = 'g'
df.loc[(df['Frame'] >= 9301) & (df['Frame'] <= 9390), 'sign'] = 'y'
df.loc[(df['Frame'] >= 9391) & (df['Frame'] <= 12000), 'sign'] = 'r'
df.loc[(df['Frame'] >= 12001) & (df['Frame'] <= 13110), 'sign'] = 'g'
df.loc[(df['Frame'] >= 13111) & (df['Frame'] <= 13200), 'sign'] = 'y'
df.loc[(df['Frame'] >= 13201) & (df['Frame'] <= 15750), 'sign'] = 'r'
df.loc[(df['Frame'] >= 15751) & (df['Frame'] <= 16860), 'sign'] = 'g'
df.loc[(df['Frame'] >= 16861) & (df['Frame'] <= 16950), 'sign'] = 'y'
df.loc[(df['Frame'] >= 16951) & (df['Frame'] <= 19290), 'sign'] = 'r'
df.loc[(df['Frame'] >= 19291) & (df['Frame'] <= 20400), 'sign'] = 'g'
df.loc[(df['Frame'] >= 20401) & (df['Frame'] <= 20490), 'sign'] = 'y'
df.loc[(df['Frame'] >= 20491) & (df['Frame'] <= 22830), 'sign'] = 'r'
df.loc[(df['Frame'] >= 22831) & (df['Frame'] <= 23940), 'sign'] = 'g'
df.loc[(df['Frame'] >= 23941) & (df['Frame'] <= 24030), 'sign'] = 'y'
df.loc[(df['Frame'] >= 24031) & (df['Frame'] <= 26730), 'sign'] = 'r'
df.loc[(df['Frame'] >= 26731) & (df['Frame'] <= 27840), 'sign'] = 'g'
df.loc[(df['Frame'] >= 27841) & (df['Frame'] <= 27930), 'sign'] = 'y'
df.loc[(df['Frame'] >= 27931) & (df['Frame'] <= 30660), 'sign'] = 'r'
df.loc[(df['Frame'] >= 30661) & (df['Frame'] <= 31860), 'sign'] = 'g'
df.loc[(df['Frame'] >= 31861) & (df['Frame'] <= 31950), 'sign'] = 'y'
df.loc[(df['Frame'] >= 31951) & (df['Frame'] <= 32428), 'sign'] = 'r'

# 将修改后的数据保存到新文件
df.to_csv('DJI668.txt', index=False, sep=' ', float_format='%.2f')
