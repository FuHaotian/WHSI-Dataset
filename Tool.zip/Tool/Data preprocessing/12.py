import pandas as pd

# 读取txt文件
df = pd.read_csv('DJI679.txt', delimiter=" ")  # 根据需要调整分隔符

# 假设X列是名为'X'，ID列是名为'ID'，你可以根据实际列名进行调整
negative_values = df[df['X'] < 0]

# 提取对应的ID
ids_with_negative_values = negative_values['id']

# 打印结果
print(ids_with_negative_values)

