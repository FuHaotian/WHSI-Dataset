import pandas as pd

# 导入txt文件，假设文件名为 'data.txt'
# 这里假设数据以空格或逗号分隔
df = pd.read_csv('DJI674.txt', delimiter=' ')  # 修改分隔符根据实际文件格式

# 替换 Velocity 列中大于 100 的值为 0
df.loc[df['Velocity'] > 100, 'Velocity'] = 0

# 输出修改后的数据
print(df)

# 可选：将修改后的数据保存回文件
df.to_csv('DJI675.txt', sep=' ', index=False)
