import pandas as pd
import numpy as np

# 读取txt文件
df = pd.read_csv('DJI677.txt', delimiter=' ')

# 确保数据按id和Frame排序
df.sort_values(by=['id', 'Frame'], inplace=True)

# 遍历数据，查找X值为0的区间并进行处理
for i in range(1, len(df)):
    if df.loc[i, 'X'] == 0:
        # 寻找X值为0的区间的两端（前后非零的X值）
        start_idx = i - 1
        end_idx = i + 1

        # 向前找到非零的X值
        while start_idx >= 0 and df.loc[start_idx, 'X'] == 0:
            start_idx -= 1

        # 向后找到非零的X值
        while end_idx < len(df) and df.loc[end_idx, 'X'] == 0:
            end_idx += 1

        # 如果找到了两端非零的X值，且两端id相同
        if start_idx >= 0 and end_idx < len(df):
            if df.loc[start_idx, 'id'] == df.loc[end_idx, 'id']:
                X_start = df.loc[start_idx, 'X']
                X_end = df.loc[end_idx, 'X']

                # 如果两端X值相等，填充整个区间
                if X_start == X_end:
                    df.loc[start_idx + 1:end_idx, 'X'] = X_start
                else:
                    # 如果两端X值不相等，进行插值填充
                    X_vals = np.linspace(X_start, X_end, end_idx - start_idx + 1)

                    # 保留插值结果的1位小数
                    X_vals = np.round(X_vals, 1)

                    # 确保插值的长度与需要填充的行数一致
                    df.loc[start_idx + 1:end_idx, 'X'] = X_vals[1:]  # 直接去掉两端，适配长度
            else:
                # 如果两端 id 不相同，将上端非零的X值填充
                X_start = df.loc[start_idx, 'X']
                # 只填充区间内的X值，不包括下端非零的X值
                df.loc[start_idx + 1:end_idx - 1, 'X'] = X_start  # 填充上端的值

# 保存修改后的数据到新的文件
df.to_csv('DJI678.txt', sep=' ', index=False)
