import pandas as pd
import numpy as np
from scipy.interpolate import CubicSpline

# 假设您已经导入数据并存储在 df 中
df = pd.read_csv('DJI678.txt', delimiter=' ')

# 计算帧率差值
df['Frame_Diff'] = df['Frame'].diff()

# 找到不连续的帧率位置，考虑相同车辆的 ID
discontinuous_indices = df[(df['Frame_Diff'] > 1) & (df['Frame_Diff'] < 50) & (df['id'].diff() == 0)].index

# 创建一个列表来存储所有的新数据
all_new_data = []

# 插值补全
for idx in discontinuous_indices:
    start_frame = df.loc[idx - 1, 'Frame']  # 上一个帧率
    end_frame = df.loc[idx, 'Frame']  # 当前帧率
    current_id = df.loc[idx, 'id']  # 当前车辆 ID

    if start_frame < end_frame - 1:  # 确保需要插值
        # 提取要插值的原始数据
        original_frames = df.loc[idx - 1:idx, 'Frame']
        original_times = df.loc[idx - 1:idx, 'Time']
        original_xs = df.loc[idx - 1:idx, 'X']
        original_ys = df.loc[idx - 1:idx, 'Y']

        # 创建样条插值对象
        cs_time = CubicSpline(original_frames, original_times)
        cs_x = CubicSpline(original_frames, original_xs)
        cs_y = CubicSpline(original_frames, original_ys)

        # 生成不均匀的插值帧，例如使用随机间隔
        new_frames = np.arange(start_frame + 1, end_frame)
        new_times = cs_time(new_frames)
        new_xs = cs_x(new_frames)
        new_ys = cs_y(new_frames)

        # 创建新的 DataFrame
        new_data = pd.DataFrame({
            'Frame': new_frames,
            'id': current_id,  # 使用当前车辆 ID
            'Time': new_times,
            'class': 'car',
            'X': new_xs,
            'Y': new_ys,
            'Velocity': 0.0,
            'Acc': 0.0,
            'landid': df.loc[idx - 1, 'landid'],
            'sign': df.loc[idx - 1, 'sign']
        })

        # 保留小数位
        new_data['Time'] = new_data['Time'].round(2)
        new_data['X'] = new_data['X'].round(1)
        new_data['Y'] = new_data['Y'].round(1)
        new_data['Velocity'] = new_data['Velocity'].round(1)
        new_data['Acc'] = new_data['Acc'].round(1)

        # 将 new_data 追加到 all_new_data 列表中
        all_new_data.append(new_data)

# 合并所有的新数据
if all_new_data:
    all_new_data = pd.concat(all_new_data, ignore_index=True)

    # 将 new_data 输出到文件
    all_new_data.to_csv('new_data3.txt', sep=' ', index=False)

    # 将 new_data 插入到原始数据 df 中
    df = pd.concat([df, all_new_data], ignore_index=True)

# 按照 'id' 和 'Frame' 列对合并后的 DataFrame进行排序
df = df.sort_values(by=['id', 'Frame']).reset_index(drop=True)

# 删除临时列
df = df.drop(columns=['Frame_Diff'])

# 输出处理后的数据
print(df)

# 可选：将结果保存回文件
df.to_csv('DJI679.txt', sep=' ', index=False)
