import pandas as pd
from tqdm import tqdm
from collections import defaultdict


# 1. 读取 TXT 文件
def load_data(file_path):
    return pd.read_csv(file_path, delim_whitespace=True)


# 2. 按车辆 ID 分组，获取每辆车的第一行和最后一行
def get_first_last_rows(df):
    grouped = df.groupby('id')
    first_rows = grouped.first().reset_index()
    last_rows = grouped.last().reset_index()
    return first_rows, last_rows


# 3. 计算差值并满足条件
def find_matching_vehicles(first_rows, last_rows):
    matched_vehicles = []

    for i in tqdm(range(len(last_rows)), desc="Processing last rows"):
        for j in range(len(first_rows)):
            if last_rows.iloc[i]['id'] != first_rows.iloc[j]['id']:
                time_diff = last_rows.iloc[i]['Time'] - first_rows.iloc[j]['Time']
                x_diff = last_rows.iloc[i]['X'] - first_rows.iloc[j]['X']
                y_diff = last_rows.iloc[i]['Y'] - first_rows.iloc[j]['Y']

                # 检查条件
                if abs(time_diff) < 0.8 and abs(x_diff) < 5 and abs(y_diff) < 1.2:
                    matched_vehicles.append((last_rows.iloc[i]['id'], first_rows.iloc[j]['id']))

    return matched_vehicles


# 4. 构建车辆关系图
def build_vehicle_graph(matched_vehicles):
    graph = defaultdict(set)
    for vehicle1, vehicle2 in matched_vehicles:
        graph[vehicle1].add(vehicle2)
        graph[vehicle2].add(vehicle1)
    return graph


# 5. 查找所有连通分量
def find_connected_components(graph):
    visited = set()
    components = []

    def dfs(vehicle, component):
        visited.add(vehicle)
        component.append(vehicle)
        for neighbor in graph[vehicle]:
            if neighbor not in visited:
                dfs(neighbor, component)

    for vehicle in graph:
        if vehicle not in visited:
            component = []
            dfs(vehicle, component)
            components.append(component)

    return components


# 6. 将所有相关车辆的行放在一起并统一 ID 为组内第一辆车的 ID，同时删除原始数据中重复的行
def combine_vehicle_data(df, components):
    combined_data = pd.DataFrame()

    for component in components:
        # 获取当前组件的车辆数据
        component_data = pd.DataFrame()

        # 按照第一个车辆 ID 作为统一 ID
        unified_id = component[0]

        for vehicle_id in component:
            vehicle_data = df[df['id'] == vehicle_id].copy()  # 使用 copy() 避免 SettingWithCopyWarning
            # 替换 ID 为该组合的第一辆车 ID
            vehicle_data.loc[:, 'id'] = unified_id
            component_data = pd.concat([component_data, vehicle_data])

        # 删除原始数据中与新合并数据重复的行
        combined_data = pd.concat([combined_data, component_data])

    # 通过检查除了 'id' 之外的所有列，删除原始数据中与合并数据重复的行
    non_id_columns = df.columns.difference(['id'])
    df_filtered = df[~df[non_id_columns].apply(tuple, 1).isin(combined_data[non_id_columns].apply(tuple, 1))]

    return combined_data, df_filtered


# 7. 保存结果到文件
def save_data(combined_data, df_filtered, output_file_path):
    # 将合并数据与过滤后的原始数据合并并保存
    final_data = pd.concat([combined_data, df_filtered])
    final_data.to_csv(output_file_path, sep=' ', index=False)


# 主函数
def main(input_file_path, output_file_path):
    df = load_data(input_file_path)
    first_rows, last_rows = get_first_last_rows(df)
    matched_vehicles = find_matching_vehicles(first_rows, last_rows)
    vehicle_graph = build_vehicle_graph(matched_vehicles)
    connected_components = find_connected_components(vehicle_graph)
    combined_data, df_filtered = combine_vehicle_data(df, connected_components)
    save_data(combined_data, df_filtered, output_file_path)


# 运行主函数

if __name__ == "__main__":
    input_file_path = 'DJI670.txt'  # 请替换为实际输入文件路径
    output_file_path = 'DJI671.txt'  # 请替换为实际输出文件路径
    main(input_file_path, output_file_path)

    # 输出结果
    print("处理完成，结果已保存。")
