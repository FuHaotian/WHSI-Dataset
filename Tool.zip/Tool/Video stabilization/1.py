import os

# 假设文件路径是中文或包含特殊字符
filename = r'DJI_0659.mp4'

# 确保使用UTF-8编码读取文件
try:
    with open(filename, 'rb') as f:  # 以二进制模式打开文件
        data = f.read()
        print("文件读取成功")
except FileNotFoundError:
    print(f"文件未找到: {filename}")
except UnicodeDecodeError:
    print(f"文件名编码错误: {filename}")
