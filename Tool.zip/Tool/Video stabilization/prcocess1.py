import cv2
import numpy as np
from tqdm import tqdm
import argparse
import os

# 获取参数
parser = argparse.ArgumentParser(description='')
parser.add_argument('-v', type=str, default='DJI_0661.mp4')  # 指定输入视频路径位置（参数必选）
parser.add_argument('-o', type=str, default='DJI_0665.MP4')  # 指定输出视频路径位置（参数必选）
parser.add_argument('-n', type=int, default=-1)  # 指定处理的帧数（参数可选）, 不设置使用视频实际帧

# 示例: python3 stable.py -v=video/01.mp4 -o=video/01_stable.mp4 -n=100

args = parser.parse_args()


input_path = args.v
output_path = args.o
number = args.n

class Stable:
    # 处理视频文件路径
    __input_path = None
    __output_path = None
    __number = number

    # surf 特征提取
    __surf = {
        'surf': None,
        'kp': None,
        'des': None,
        'template_kp': None
    }

    # 捕获
    __capture = {
        'cap': None,
        'size': None,
        'frame_count': None,
        'fps': None,
        'video': None,
    }

    # 配置
    __config = {
        'key_point_count': 5000,
        'index_params': dict(algorithm=0, trees=5),
        'search_params': dict(checks=50),
        'ratio': 0.5,
    }

    def __init__(self):
        pass

    def __init_capture(self):
        self.__capture['cap'] = cv2.VideoCapture(self.__input_path)
        self.__capture['size'] = (int(self.__capture['cap'].get(cv2.CAP_PROP_FRAME_WIDTH)),
                                  int(self.__capture['cap'].get(cv2.CAP_PROP_FRAME_HEIGHT)))
        self.__capture['fps'] = self.__capture['cap'].get(cv2.CAP_PROP_FPS)
        self.__capture['video'] = cv2.VideoWriter(self.__output_path, cv2.VideoWriter_fourcc(*"mp4v"),
                                                  self.__capture['fps'], self.__capture['size'])
        self.__capture['frame_count'] = int(self.__capture['cap'].get(cv2.CAP_PROP_FRAME_COUNT))

        if self.__number == -1:
            self.__number = self.__capture['frame_count']
        else:
            self.__number = min(self.__number, self.__capture['frame_count'])

    def __init_surf(self):
        self.__capture['cap'].set(cv2.CAP_PROP_POS_FRAMES, 0)
        state, first_frame = self.__capture['cap'].read()

        self.__capture['cap'].set(cv2.CAP_PROP_POS_FRAMES, self.__capture['frame_count'] - 1)
        state, last_frame = self.__capture['cap'].read()

        self.__surf['surf'] = cv2.xfeatures2d.SURF_create(self.__config['key_point_count'])

        self.__surf['kp'], self.__surf['des'] = self.__surf['surf'].detectAndCompute(first_frame, None)
        kp, des = self.__surf['surf'].detectAndCompute(last_frame, None)

        flann = cv2.FlannBasedMatcher(self.__config['index_params'], self.__config['search_params'])
        matches = flann.knnMatch(self.__surf['des'], des, k=2)

        good_match = []
        for m, n in matches:
            if m.distance < self.__config['ratio'] * n.distance:
                good_match.append(m)

        self.__surf['template_kp'] = []
        for f in good_match:
            self.__surf['template_kp'].append(self.__surf['kp'][f.queryIdx])

    def __release(self):
        self.__capture['video'].release()
        self.__capture['cap'].release()

    def __process(self):
        current_frame = 1
        self.__capture['cap'].set(cv2.CAP_PROP_POS_FRAMES, 0)

        # 初始化进度条
        process_bar = tqdm(total=self.__number, desc='处理帧', unit='帧')

        while current_frame <= self.__number:
            success, frame = self.__capture['cap'].read()

            if not success:
                break  # 如果未成功读取帧，则退出循环

            # 计算稳定帧
            frame = self.detect_compute(frame)

            # 写入稳定帧
            self.__capture['video'].write(frame)

            current_frame += 1

            # 更新进度条
            process_bar.update(1)

        # 关闭进度条
        process_bar.close()

    def stable(self, input_path, output_path, number):
        self.__input_path = input_path
        self.__output_path = output_path
        self.__number = number

        self.__init_capture()
        self.__init_surf()
        self.__process()
        self.__release()

    def detect_compute(self, frame):
        frame_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        kp, des = self.__surf['surf'].detectAndCompute(frame_gray, None)

        flann = cv2.FlannBasedMatcher(self.__config['index_params'], self.__config['search_params'])
        matches = flann.knnMatch(self.__surf['des'], des, k=2)

        good_match = []
        for m, n in matches:
            if m.distance < self.__config['ratio'] * n.distance:
                good_match.append(m)

        p1, p2 = [], []
        for f in good_match:
            if self.__surf['kp'][f.queryIdx] in self.__surf['template_kp']:
                p1.append(self.__surf['kp'][f.queryIdx].pt)
                p2.append(kp[f.trainIdx].pt)

        H, _ = cv2.findHomography(np.float32(p2), np.float32(p1), cv2.RHO)

        output_frame = cv2.warpPerspective(frame, H, self.__capture['size'], borderMode=cv2.BORDER_REPLICATE)

        return output_frame


if __name__ == '__main__':
    if not os.path.exists(input_path):
        print(f'[错误] 文件 "{input_path}" 未找到')
        exit(0)
    else:
        print(f'[信息] 视频 "{input_path}" 稳定处理开始')

    s = Stable()
    s.stable(input_path, output_path, number)

    print('[信息] 完成.')
    exit(0)
